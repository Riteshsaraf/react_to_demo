# react-todo-demo


It's a simple todo application contains redux with an api setup 

If you want to use this structure you can use this inbuild with enhancing routing and other components 
