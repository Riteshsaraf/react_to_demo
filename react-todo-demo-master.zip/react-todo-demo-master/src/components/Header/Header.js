
import React from "react";

function Header({company={}}) {


    return (

     <nav className="navbar sticky-top navbar-expand-lg navbar-light bg-dark">
        
     </nav>
    );
}

export default Header;