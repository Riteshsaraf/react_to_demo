import React from "react";

function Footer({ user, offices = [], company = {} }) {

    return (
        <>

            <section>
            </section>
        </>
    );
}

export default Footer;