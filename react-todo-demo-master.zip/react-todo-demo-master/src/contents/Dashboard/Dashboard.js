import React, { useEffect, useState } from "react";

function Dashboard({ events, appreciations, partners, company={},  setting ={}}) {

    useEffect(()=>{

    },[setting])

    return (
        <>

            <section>
            </section>

        </>
    );
}
export default Dashboard;